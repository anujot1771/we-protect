package com.lambton.lofterapp.utils;

public class Utility {

    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;
    public static final int REQUEST_CAMERA = 100;
    public static final int REQUEST_MULTIPLE_PERMISSIONS = 102;
    public static final int SELECT_FILE = 200;

    public static final String urlNavHeaderBg = "https://api.androidhive.info/images/nav-menu-header-bg.jpg";

    public static String cameraFilePath;

    public static final String KEY_FIRST_RUN = "first_run";
}
