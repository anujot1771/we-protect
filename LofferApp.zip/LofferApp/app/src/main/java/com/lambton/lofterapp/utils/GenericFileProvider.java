package com.lambton.lofterapp.utils;

import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
